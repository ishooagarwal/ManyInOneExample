﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stucts.BaseInterface
{
    interface IExpireHelper
    {
        bool Expire { get; set; }
    }
}
