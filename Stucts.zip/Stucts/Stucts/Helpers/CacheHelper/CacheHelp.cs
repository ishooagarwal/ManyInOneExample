﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Stucts.ReflectionHelper;

namespace Stucts.Helpers.CacheHelper
{
    class CacheHelp
    {
        Type t = null;
        public CacheHelp()
        {
            
        }
    }
}
